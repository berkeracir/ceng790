package edu.metu.ceng790

object scrap {;import org.scalaide.worksheet.runtime.library.WorksheetSupport._; def main(args: Array[String])=$execute{;$skip(84); 
  println("Welcome to the Scala worksheet");$skip(27); 
  
  val data = 1 to 10000;System.out.println("""data  : scala.collection.immutable.Range.Inclusive = """ + $show(data ))}
  
}
