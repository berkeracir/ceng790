object scrap {;import org.scalaide.worksheet.runtime.library.WorksheetSupport._; def main(args: Array[String])=$execute{;$skip(58); 
  println("Welcome to the Scala worksheet");$skip(27); 
  
  val data = 1 to 10000;System.out.println("""data  : scala.collection.immutable.Range.Inclusive = """ + $show(data ));$skip(5); val res$0 = 
  ss;System.out.println("""res0: <error> = """ + $show(res$0))}
  
  
}
