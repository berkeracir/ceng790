object scratch {;import org.scalaide.worksheet.runtime.library.WorksheetSupport._; def main(args: Array[String])=$execute{;$skip(60); 
  println("Welcome to the Scala worksheet");$skip(21); 
  
  val a = 7.0/0.0;System.out.println("""a  : Double = """ + $show(a ))}
  
}
